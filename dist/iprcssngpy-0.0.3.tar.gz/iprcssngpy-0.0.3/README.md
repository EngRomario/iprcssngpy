# IPrcssngPy
The package IPrcssngPy is used to:
- Processing:
  -  Histrogram matching
  - Structural similarity
  - Resize image
- Utils:
  - Read image
  - Save image
  - Plot image
  - Plot result
  - Plot histogram
## Installation
Use the packpage manager [pip](https://pip.pypa.io/en/stable/) to install IPrcssngPy
```bash
pip install iprcssngpy
```
## Author
Romário Pereira Marinho
## License
[MIT](https://choosealicense.com/licenses/mit/)